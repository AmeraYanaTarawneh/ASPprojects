﻿using APIproject2.Data;
using APIproject2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIproject2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private APIDbContext db;
        public EmployeesController(APIDbContext _db)
        {
            db = _db;
        }

        //  -------------------------------------------------------------------------------------
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployees()
        {
            return await db.Employees.OrderByDescending(x => x.EmployeeId).ToListAsync();
        }



        //  -------------------------------------------------------------------------------------
        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            if (id == null)
            {
                return BadRequest(string.Empty);
            }
            var data = await db.Employees.FindAsync(id);

            if (data == null)
            {
                return NotFound();
            }

            return Ok(data);
        }




        [HttpGet("byname")]
        public async Task<ActionResult<Employee>> GetEmployeeByName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return BadRequest("Name is required.");
            }

            var data = await db.Employees.FirstOrDefaultAsync(emp => emp.EmployeeName == name);

            if (data == null)
            {
                return NotFound("Employee not found.");
            }

            return Ok(data);
        }

       
        
        
        
        
        // Insert -------------------------------------------------------------------------------------
        [HttpPost]
        public async Task<ActionResult<Employee>> PostEmployee([FromBody] Employee employee)
        {
            if (employee == null)
            {
                return BadRequest("Employee data is required.");
            }

            // You can perform additional validation on the employee data here
            if (ModelState.IsValid)
            {
                db.Employees.Add(employee);
                await db.SaveChangesAsync();
                return Ok();
            }

            return null!;
        }









        // Edit -------------------------------------------------------------------------------------
        [HttpPut("{id}")]
        public async Task<ActionResult<Employee>> PutEmployee(Employee employee,int? id) 
        {
            if (employee == null) {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                if(id == null)
                {
                    return BadRequest();
                }
                var data = db.Employees.AsNoTracking().Where(x => x.EmployeeId == id).SingleOrDefault();

                // when toy take obj in the same place twice >> track the id 
                // use AsNoTracking to avoide the old and use new one 
                if (data == null)
                {
                    return NotFound();
                }
                //check also this 
                //send on body something but change it in url
                // so i need them equal
                if (id == employee.EmployeeId) 
                {
                    try
                    {
                    db.Employees.Update(employee);
                    }
                    catch (Exception ex)
                    {

                        string  msg = ex.Message;
                        return BadRequest(msg);
                    }
                     
                    await db.SaveChangesAsync();
                    return NoContent();
                }
            }
            return NotFound("Id not match with current model");
        }




        // Delete -------------------------------------------------------------------------------------
        [HttpDelete("{id}")]
        public async Task<ActionResult<Employee>> DeleteEmployee(Employee employee, int? id)
        {
            if (employee == null)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                if (id == null)
                {
                    return BadRequest();
                }
                var data = db.Employees.AsNoTracking().Where(x => x.EmployeeId == id).SingleOrDefault();

                // when toy take obj in the same place twice >> track the id 
                // use AsNoTracking to avoide the old and use new one 
                if (data == null)
                {
                    return NotFound();
                }
                //check also this 
                //send on body something but change it in url
                // so i need them equal
                if (id == employee.EmployeeId)
                {
                    try
                    {
                        db.Employees.Remove(employee);
                    }
                    catch (Exception ex)
                    {

                        string msg = ex.Message;
                        return BadRequest(msg);
                    }

                    await db.SaveChangesAsync();
                    return NoContent();
                }
            }
            return NotFound("Id not match with current model");
        }














        //[HttpGet("{name}")]
        //public async Task<ActionResult<Employee>> GetEmployee(string name)
        //{
        //    if (name == null)
        //    {
        //        return BadRequest(string.Empty);
        //    }
        //    var data = await db.Employees.FindAsync(name);

        //    if (data == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(data);
        //}


        //[HttpGet]
        //public async Task<ActionResult<Employee>> GetEmployee(int id)
        //{
        //    if (id == null)
        //    { 
        //        return BadRequest(string.Empty);
        //    }
        //    var data = await db.Employees.FirstAsync(id);
        //    if (data == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(data);    
        //}

    }
}
