﻿using APIproject2.Models;
using Microsoft.EntityFrameworkCore;

namespace APIproject2.Data
{
    public class APIDbContext : DbContext
    {
        public APIDbContext(DbContextOptions<APIDbContext> options):base(options)
        {
                
        }
        public DbSet<Employee> Employees { get; set; }

    }
}
