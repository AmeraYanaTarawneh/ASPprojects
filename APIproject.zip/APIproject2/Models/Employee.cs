﻿using System.ComponentModel.DataAnnotations;

namespace APIproject2.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        [Required(ErrorMessage ="Enter Name")]
        public string? EmployeeName { get; set; }
        [Required(ErrorMessage = "Enter Name")]
        [MinLength(3,ErrorMessage ="Min Char3")]
        public string? City { get; set; }
    }
}
