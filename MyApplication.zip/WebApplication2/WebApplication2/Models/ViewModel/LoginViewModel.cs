﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models.ViewModel
{
    public class LoginViewModel
    {

        [Display(Name = "Your Email")]
        [EmailAddress]//annotations
        [Required(ErrorMessage = "Enter Email")]
        public string? Email { get; set; }



        [Display(Name = "Your Password")]
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string? Password { get; set; }

        public bool Remmemberme { get; set; }
    }
}
