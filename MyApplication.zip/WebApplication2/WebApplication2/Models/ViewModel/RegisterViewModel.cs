﻿using System.ComponentModel.DataAnnotations;


namespace WebApplication2.Models.ViewModel
{
    public class RegisterViewModel
    {

        ////[Display(Name = "Your Name")]
        ////[Required(ErrorMessage = "Enter Name")]
        ////public string? UserName { get; set; }




        [Display(Name ="Your Email")]
        [EmailAddress]//annotations
        [Required(ErrorMessage = "Enter Email")]
        public string? Email { get; set; }



        [Display(Name = "Your Password")]
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string? Password { get; set; }



        [Required(ErrorMessage = "Enter Confirm Password")]
        [DataType(DataType.Password)]//modle state
        [Compare("Password", ErrorMessage = "Error not match")]
        public string? ConfirmPassword { get; set; }


        [Display(Name = "PhoneNumber")]
        public  string? PhoneNumber { get; set;}
    }
}
