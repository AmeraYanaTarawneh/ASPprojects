﻿namespace WebApplication2.Models.ViewModel
{
    public class UserRoleViewModel
    {
        public string? UserId { get; set; }

        public string? UserName { get; set; }//8 #13

        public bool IsSelected { get; set; }    
    }
}
