﻿namespace WebApplication2.Models.ViewModel
{
    public class EditRoleViewModel
    {
        // 20:00 #12
        public EditRoleViewModel()  
        {
            Users = new List<string>(); //initilize the list of string 
        }  
        public string? RoleId { get; set; }

        public string? RoleName{ get; set; }


        public List<string>? Users { get;set; }

    }
}
