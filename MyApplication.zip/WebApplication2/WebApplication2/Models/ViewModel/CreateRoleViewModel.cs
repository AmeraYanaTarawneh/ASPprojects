﻿using System.ComponentModel.DataAnnotations;
using System.Security.Principal;

namespace WebApplication2.Models.ViewModel
{
    public class CreateRoleViewModel
    {
        [Required]
        public String? RoleName { get; set; } 
    }
}
