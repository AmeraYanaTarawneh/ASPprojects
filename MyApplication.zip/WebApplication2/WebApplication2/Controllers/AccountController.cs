﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApplication2.Data;
using WebApplication2.Models.ViewModel;

namespace WebApplication2.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private AppDbContext db;//this outer db became obj from the class 
        private UserManager<IdentityUser> userManager; // UserManager of ...
        private RoleManager<IdentityRole> roleManager; // UserManager of ...
        private SignInManager<IdentityUser> signInManager;

        public AccountController
            (
            AppDbContext _db, 
            UserManager<IdentityUser> _userManager,
            SignInManager<IdentityUser> _signInManager,
            RoleManager<IdentityRole> _roleManager
            ) //injection

        { 
            db = _db;
            userManager = _userManager;
            signInManager = _signInManager;
            roleManager = _roleManager;
        }



        //-------------------------------------------------------------------------------------------
        [AllowAnonymous]
        public IActionResult Register()
        { 
            return View();
        }


        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
                if (ModelState.IsValid)
                {
                        IdentityUser user = new IdentityUser
                        {
                            UserName = model.Email,
                            Email = model.Email,
                            PhoneNumber = model.PhoneNumber
                        };

                        var result= await userManager.CreateAsync(user,model.Password); //becouse the pass is hashed

                        if (result.Succeeded)
                        {
                            return RedirectToAction("Login");
                        }
   
                        foreach (var err in result.Errors)
                        {
                            ModelState.AddModelError(err.Code, err.Description);
                            return View(model);
                        }

                }

                //if the whole state is in-valid , it will return the same view 
                return View(model);

        }







        //-------------------------------------------------------------------------------------------
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }



        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {

                var result = await signInManager.PasswordSignInAsync(model.Email, model.Password,model.Remmemberme,false);

                if (result.Succeeded)
                {
                    return RedirectToAction("UserAccountMainPage", "UserAccountPage");
                }


                ModelState.AddModelError("", "Invalid user or pass");
                return View(model);


            }
            return View(model);

        }






        //-------------------------------------------------------------------------------------------
       
        public async Task<IActionResult> Logout() 
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login","Account");    
        }



        //-------------------------------------------------------------------------------------------
        [Authorize(Roles ="Admin")]
        public IActionResult CreateRole()
        {
            
            return View();

        }

        
        [Authorize(Roles ="Admin")]
        [HttpPost]
        public async Task<IActionResult> CreateRole(CreateRoleViewModel model)
        {

            if (ModelState.IsValid)
            {
                IdentityRole role = new IdentityRole
                {
                    Name = model.RoleName
                };

                var result = await roleManager.CreateAsync(role); //becouse the pass is hashed

                if (result.Succeeded)
                {
                    return RedirectToAction("RoleList");
                }

                 return View(model);

            }

          
            return View(model);

        }



        [Authorize(Roles = "Admin")]
        public IActionResult RoleList()
        { 
            return View(roleManager.Roles); 
        }


        //-------------------------------------------------------------------------------------------
        public async Task<IActionResult> EditRole(string id) 
        { 
            //how to do the search  
             var data=await roleManager.FindByIdAsync(id);
            if (data == null)
            {
                return RedirectToAction("RolesList ");
            }

            // put yhe data inside obj of type edit viwe model 
            // passed edit viwe model ,, bestaqbel from type edit view model


            EditRoleViewModel model = new EditRoleViewModel
            {
                RoleId = data.Id,
                RoleName= data.Name,    
            };

            foreach (var user in userManager.Users)//loop on all the users   1:14 #12
            { 
                if (await userManager.IsInRoleAsync(user,data.Name!))
                {
                    model.Users!.Add(user.UserName!);
                }
            
            }

            return View(model);  // bring the data and return if any on the page
            // so it became the same type as type he bestaqbelin view
        }


        [HttpPost] // bestaqbel  model 
        public async Task<IActionResult> EditRole(EditRoleViewModel m)
        {

            if (ModelState.IsValid)
            {
                //not right
                //IdentityRole role = new IdentityRole
                //{
                //    Id = m.RoleId,
                //    Name = m.RoleName
                //};

                //52 #12 !!!!!!!!!! back to understand 
                var role = await roleManager.FindByIdAsync(m.RoleId!);
                role!.Name=m.RoleName;
                var result = await roleManager.UpdateAsync(role); //becouse the pass is hashed

                        if (result.Succeeded)
                        {
                            return RedirectToAction("RoleList");
                        }
                        foreach(var err in result.Errors)
                        {
                           ModelState.AddModelError(err.Code, err.Description);
                        }

                        return View(m);

            }
            return View(m);








        }




//-------------------------------------------------------------------------------------------
        public async Task<IActionResult> DeleteRole(string id)
        {
            var role = await roleManager.FindByIdAsync(id);

            if (role == null)
            {
                // Role not found
                return RedirectToAction("RoleList");
            }

            var result = await roleManager.DeleteAsync(role);

            if (result.Succeeded)
            {
                // Role deleted successfully
                return RedirectToAction("RoleList");
            }
            else
            {
                // Error occurred while deleting the role
                // You can handle the error and display an appropriate view
                return RedirectToAction("RoleList");
            }
        }
    }











    //[HttpGet]
    //public async Task<IActionResult> EditUsersInRole(string id)
    //{

    //        if (id==null)
    //        {
    //            return RedirectToAction("RoleList");
    //        }

    //        var role=await roleManager.FindByIdAsync(id);   
    //        if(role==null) 
    //        {
    //            return RedirectToAction("RoleList");
    //        }

    //        List<UserRoleViewModel>  model = new List<UserRoleViewModel>();

    //        foreach (var user in userManager.Users)
    //        { //now make new obj
    //        //why? to bring its data and save it 
    //            UserRoleViewModel userRoleViewModel  = new UserRoleViewModel
    //            {
    //                UserId = user.Id,
    //                UserName= user.UserName
    //            };

    //            if (await userManager.IsInRoleAsync(user,role.Name!))
    //            {
    //                userRoleViewModel.IsSelected= true; 
    //            }
    //            model.Add(userRoleViewModel);
    //        }
    //        return View(model);
    //}



    //[HttpPost]

    //public async Task<IActionResult> EditUsersInRole(string id, List<UserRoleViewModel> models)
    //{

    //    return View();
    //}




}


