﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class UserAccountPage : Controller
    {
        public IActionResult UserAccountMainPage()
        {
            return View();
        }
    }
}
